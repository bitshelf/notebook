#!/bin/bash
#########
#for update image copy from server
#########

comment(){
	if [ ! $1 ];then
		echo -n "please input board type:
				1 a311d
				2 s905
："
		read board
	fi
	
	# if [ x$1 == x1 ] || [ x$board == x1 ];then
	 if [ x$1 == x1 -o x$board == x1 ];then
		board=w400		#w400 for a311d, u202 for s905
		echo $board
		elif [ x$1 == x2 ] || [ x$board == x2 ];then
			board=u202
			echo $board
	fi
}

#server_path=rpdzkj_debug@192.168.1.51:		#51server
server_path=rpdzkj@192.168.1.90:		#90server

#source_path=/home/rpdzkj_debug/second/joysing/a311d-s905-android9/android9.0/		#51source joysing
#source_path=/home/rpdzkj/fifth/tanzh/a311d-s905d3-android9.0/20201112/android9.0/		#90source tan
#source_path=/home/rpdzkj/third/joysing/linux/a311d-linux/buildroot-openlinux-g12b/output/mesong12b_w400_release/images/		#90source linux
source_path=/home/rpdzkj/third/joysing/linux/s905d3-linux/buildroot/output/sm1_ac200_a6432_release/images/		#90source linux for s905

uboot_path=${source_path}u-boot.bin
kernel_path=${source_path}boot.img
dts_path=${source_path}dtb.img

echo $server_path


variable=$1
if [ $variable ];then
	echo -e "\n\tobject: $variable...\n"
	case $variable in
		"kernel" )
			scp.exe $server_path$kernel_path .
			;;
		"uboot" )
			scp.exe $server_path$uboot_path .
			;;
		"dts" )
			scp.exe $server_path$dts_path .
			;;
	  * )
		  echo -e "\n\tparameter error!\n"
		  exit -1
  	esac
	if [ $? == 0 ];then
		echo -e "\n\tcopy $variable frome server ok!\n"
		else
			echo -e "\n\tcopy $variable fail!\n"
			exit -1
	fi
else 
	echo -e "\n\tnew object is all...\n"
	scp.exe $server_path$kernel_path .
	scp.exe $server_path$uboot_path .
	scp.exe $server_path$dts_path .
fi
