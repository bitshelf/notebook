@echo off

:BEGIN
echo ****** rpdzkj update amlogic android9.0 ******
echo:
echo  1: uboot           ---- u-boot.bin
echo  2: kernel          ---- boot.img
echo  3: dts             ---- nano-box-a311d.dtb
echo  4: dts             ---- nano-box-s905d3.dtb
echo  5: dts             ---- rp-a311d.dtb
echo  6: system          ---- ubuntu-desktop.img


echo:
set /p var=Which number you like?number you want to burn, other exit...

fastboot flashing unlock_critical
fastboot flashing unlock

if %var%==1 fastboot flash bootloader u-boot.bin
if %var%==2 fastboot flash boot boot.img
if %var%==3 fastboot flash dtb nano-box-a311d.dtb
if %var%==4 fastboot flash dtb nano-box-s905d3.dtb
if %var%==5 fastboot flash dtb rp-a311d.dtb
if %var%==6 fastboot flash system ubuntu-desktop.img
if %var% lss 1 goto END
if %var% gtr 6 goto END

fastboot flashing lock_critical
fastboot flashing lock
fastboot reboot



echo:
echo ************************************
echo update success , please reset system
echo ************************************
echo:

goto BEGIN

:END
pause
