#include<opencv2/opencv.hpp>
using namespace cv;

int main()
{
    VideoCapture cap;
    cap.open(0); //打开摄像头
    cap.set(CAP_PROP_FPS, 30);
    cap.set(CAP_PROP_FRAME_WIDTH, 800);
    cap.set(CAP_PROP_FRAME_HEIGHT, 480);
    if(!cap.isOpened())
        return 0;

    Mat frame;
    while(1)
    {
        cap>>frame;//等价于cap.read(frame);
        if(frame.empty())
            break;
        imshow("video", frame);
	waitKey(30);
    }
    cap.release();
    destroyAllWindows();//关闭所有窗口
    return 0;
}
