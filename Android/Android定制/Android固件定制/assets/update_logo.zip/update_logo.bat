:: use adb update

@echo off
call:RunACmd "adb\adb.exe root"
ping 127.0.0.1 -n 3 > nul
call:RunACmd  "adb\adb.exe push .\logo\logo.bmp /sdcard/"
call:RunACmd  "adb\adb.exe push .\logo\logo_kernel.bmp /sdcard/"
call:RunACmd  "adb\adb.exe shell < shell.txt"
::call:RunACmd  "adb\adb.exe shell 'cd /sdcard/;cat logo.bmp > logo.img && truncate -s %512 logo.img && cat logo_kernel.bmp >> logo.img'"
::call:RunACmd  "adb\adb.exe shell 'cd /sdcard; dd if=logo.img of=/dev/block/by-name/logo'"
ping 127.0.0.1 -n 1 > nul
call:RunACmd "adb\adb.exe shell sync"

pause
exit

:RunACmd
SETLOCAL
set CmdStr=%1
echo IIIIIIIIIIIIIIII Run Cmd:  %CmdStr% 
%CmdStr:~1,-1% || goto RunACmd

GOTO:EOF