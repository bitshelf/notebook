#!/bin/bash
# apply-all.sh — 应用本补丁目录中的所有补丁
#                Apply all patches from this patch directory
#
# 用法 Usage:  bash patch-YYYYMMDD/apply-all.sh
#   或者设置 SDK_ROOT 覆盖自动检测 / Or set SDK_ROOT to override auto-detection.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# ── 自动检测 SDK 根目录 / Auto-detect SDK root ──────────────────────────────
find_repo() {
    if [ -f ".repo/repo/repo" ]; then echo ".repo/repo/repo"
    elif command -v repo &>/dev/null; then echo "repo"
    else echo ""; fi
}
REPO_CMD=$(find_repo)

if [ -n "${SDK_ROOT:-}" ]; then
    ROOT="$SDK_ROOT"
elif [ -n "$REPO_CMD" ]; then
    ROOT="$($REPO_CMD --show-toplevel 2>/dev/null || true)"
fi
ROOT="${ROOT:-$(pwd)}"

# ── 加载路径映射（自动生成）/ Load path mapping (auto-generated) ────────────
declare -A REPO_MAP
while IFS= read -r line; do
    [[ "$line" =~ ^(.+)[[:space:]]:[[:space:]](.+)$ ]] || continue
    REPO_MAP["${BASH_REMATCH[1]}"]="${BASH_REMATCH[2]}"
done <<'__MAP__'
buildroot : buildroot
buildroot : buildroot
kernel-6.1 : kernel-6.1
rkbin : rkbin
u-boot : u-boot
__MAP__

echo "══ apply-all ══════════════════════════════════════════════════"
echo "  补丁目录 Patches : $SCRIPT_DIR"
echo "  根目录   Root    : $ROOT"
echo ""

OK=0
FAIL=0
SKIP=0

shopt -s nullglob
PATCHES=("$SCRIPT_DIR"/patches/*.patch)
shopt -u nullglob

if [ ${#PATCHES[@]} -eq 0 ]; then
    echo "  patches/ 中没有找到 .patch 文件 / No .patch files found in patches/"
    exit 0
fi

for p in "${PATCHES[@]}"; do
    pname=$(basename "$p")
    # 提取前缀：-NNNN- 之前的部分 / Extract prefix: everything before -NNNN-
    prefix=$(echo "$pname" | sed 's/-[0-9]\{4\}-.*//')
    repo_path="${REPO_MAP[$prefix]:-$prefix}"

    TARGET="$ROOT/$repo_path"
    if [ ! -d "$TARGET" ]; then
        echo "  [SKIP] $pname — 未找到仓库路径 / repo path not found: $repo_path"
        SKIP=$((SKIP + 1))
        continue
    fi

    echo "  [$repo_path] $pname"

    if (cd "$TARGET" && git am --quiet "$p" 2>/dev/null); then
        echo "    [✓]  应用成功 applied"
        OK=$((OK + 1))
    else
        echo "    [✗]  冲突 conflict — 已中止 aborting，请手动复制 source/ 目录下的文件 / use source/ to copy manually"
        (cd "$TARGET" && git am --abort 2>/dev/null) || true
        FAIL=$((FAIL + 1))
    fi
done

echo ""
echo "══ 汇总 Summary ════════════════════════════════════════════════"
echo "  总数 Total : ${#PATCHES[@]}"
echo "  成功 OK    : $OK"
if [ $SKIP -gt 0 ]; then echo "  跳过 Skip  : $SKIP"; fi
if [ $FAIL -gt 0 ]; then echo "  失败 Fail  : $FAIL"; fi
