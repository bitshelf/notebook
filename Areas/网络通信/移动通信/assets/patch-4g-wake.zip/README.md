# 补丁 Patches — 2026-10-16

生成时间 Generated: **2026-10-16 17:11:28**
补丁总数 Total patches: **5**

---

## 补丁列表 / Patch List

### `buildroot`

  [✓] buildroot -> buildroot-0001-FEAT-board-add-30-usb-wakeup-overlay-4G-USB-wakeup-a.patch
  [✓] buildroot -> buildroot-0002-package-quectel-cm-add-missing-hash-file.patch

### `kernel-6.1`

  [✓] kernel-6.1 -> kernel-6.1-0001-FEAT-4G-wakeup.patch

### `rkbin`

  [✓] rkbin -> rkbin-0001-FEAT-rk3576-replace-bl31-with-no-pd-php-build-4G-wak.patch

### `u-boot`

  [✓] u-boot -> u-boot-0001-FEAT-spl-relocate-control-fdt-to-avoid-BL31-load-win.patch

---

## 如何应用 / How to Apply

### 方法一 Method 1 — 应用全部补丁（推荐）Apply all patches (recommended)

```bash
bash patch-20261016/apply-all.sh
```

### 方法二 Method 2 — 应用单个补丁 Apply a single patch

```bash
cd $SDK_ROOT/<repo-path>
git am /path/to/patch-20261016/patches/<prefix>-NNNN-xxx.patch
```

### 方法三 Method 3 — 备选方案：手动复制源文件（补丁冲突时）/ Fallback: copy source files manually (when patch conflicts)

```bash
# 如果 git am 失败，直接复制导出的源文件 / If git am fails, copy the exported source files directly:
SRC="patch-20261016/source/<repo-path>"
DST="$SDK_ROOT/<repo-path>"
(cd "$SRC" && find . -type f | while read f; do install -D "$f" "$DST/$f"; done)
```

### 方法四 Method 4 — 应用前检查（演练）Check before applying (dry-run)

```bash
cd $SDK_ROOT/<repo-path>
git apply --stat /path/to/patch-20261016/<prefix>-NNNN-xxx.patch   # 预览 preview
git apply --check /path/to/patch-20261016/<prefix>-NNNN-xxx.patch  # 验证 verify
```

---

## 如何回退 / How to Revert

```bash
cd $SDK_ROOT/<repo-path>
git log --oneline -1   # 查看将被回退的提交 / see what will be reverted
git reset --hard HEAD~1
```
